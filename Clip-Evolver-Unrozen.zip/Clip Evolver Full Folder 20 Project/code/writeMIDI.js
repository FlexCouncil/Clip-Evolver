// Adapted from http://compusition.com by Adam Murray.
// This devices also uses Magenta.js, which operates under the following license:
// https://github.com/magenta/magenta-js/blob/master/LICENSE

inlets = 1;
outlets = 1;

var track = 0;
var scene = 0;
var buffer_state = 0;
var probability = 1.0;
var velocity = 100;
var velocity_deviation = 0.0;
var release_velocity = 64;
var replacement_notes_global = [];

var c_natural = true;
var c_sharp = true;
var d_natural = true;
var d_sharp = true;
var e_natural = true;
var f_natural = true;
var f_sharp = true;
var g_natural = true;
var g_sharp = true;
var a_natural = true;
var a_sharp = true;
var b_natural = true;

var lo_oct = -2;
var hi_oct = 8;

function setTrack(inputTrack) {
  track = inputTrack; 
}

function setScene(inputScene) {
  scene = inputScene;
}

function setBufferState(inputBufferState) {
  buffer_state = inputBufferState;
}

function setProbability(inputProbability) {
  probability = inputProbability;
}

function setVelocity(inputVelocity) {
  velocity = inputVelocity;
}

function setVelocityDeviation(inputVelocityDeviation) {
  velocity_deviation = inputVelocityDeviation;
}

function setReleaseVelocity(inputReleaseVelocity) {
  release_velocity = inputReleaseVelocity;
}

function setCNatural(inputCNatural) {
  if (inputCNatural == 1) {
    c_natural = true;
  } else {
	c_natural = false;
  }
}

function setCSharp(inputCSharp) {
  if (inputCSharp == 1) {
    c_sharp = true;
  } else {
	c_sharp = false;
  }
}

function setDNatural(inputDNatural) {
  if (inputDNatural == 1) {
    d_natural = true;
  } else {
	d_natural = false;
  }
}

function setDSharp(inputDSharp) {
  if (inputDSharp == 1) {
    d_sharp = true;
  } else {
	d_sharp = false;
  }
}

function setENatural(inputENatural) {
  if (inputENatural == 1) {
    e_natural = true;
  } else {
	e_natural = false;
  }
}

function setFNatural(inputFNatural) {
  if (inputFNatural == 1) {
    f_natural = true;
  } else {
	f_natural = false;
  }
}

function setFSharp(inputFSharp) {
  if (inputFSharp == 1) {
    f_sharp = true;
  } else {
	f_sharp = false;
  }
}

function setGNatural(inputGNatural) {
  if (inputGNatural == 1) {
    g_natural = true;
  } else {
	g_natural = false;
  }
}

function setGSharp(inputGSharp) {
  if (inputGSharp == 1) {
    g_sharp = true;
  } else {
	g_sharp = false;
  }
}

function setANatural(inputANatural) {
  if (inputANatural == 1) {
    a_natural = true;
  } else {
	a_natural = false;
  }
}

function setASharp(inputASharp) {
  if (inputASharp == 1) {
    a_sharp = true;
  } else {
	a_sharp = false;
  }
}

function setBNatural(inputBNatural) {
  if (inputBNatural == 1) {
    b_natural = true;
  } else {
	b_natural = false;
  }
}

function setLoOct(inputLoOct) {
  lo_oct = inputLoOct;
}

function setHiOct(inputHiOct) {
  hi_oct = inputHiOct;
}

//--------------------------------------------------------------------
// Clip class
 
function Clip() {
  var path = "live_set tracks " + track + " clip_slots " + scene + " clip";
  this.liveObject = new LiveAPI(path);
}
  
Clip.prototype.getLength = function() {
  return this.liveObject.get('length');
}

Clip.prototype._sendNotes = function(notes) {
  var liveObject = this.liveObject;
  liveObject.call("notes", notes.length);
  notes.forEach(function(note) {
    liveObject.call("note", note.getPitch(),
                    note.getStartTime(), note.getDuration(),
                    note.getVelocity(), note.getProbability(), note.getVelocityDeviation(), note.getReleaseVelocity(), note.getMute());
  });
  liveObject.call('done');
}
 
Clip.prototype.removeNotesExtended = function(removeTimeRange) {
  this.liveObject.call("remove_notes_extended", 0, 127, 0, removeTimeRange);
}

Clip.prototype.addNewNotes = function(notes) {
  var notesObject = {notes: notes};
  var notesJson = JSON.stringify(notesObject)
  this.liveObject.call("add_new_notes", notesJson);
  // this._sendNotes(notes);
}
 
Clip.prototype.replaceAllNotes = function(notes) {
  var removeTimeRange = this.getLength();
  this.removeNotesExtended(removeTimeRange);
  this.addNewNotes(notes);
}

//--------------------------------------------------------------------
// Note class
 
function Note(pitch, startTime, duration, velocity, mute, probability, velocityDeviation, releaseVelocity) {
  this.pitch = pitch;
  this.start_time = startTime;
  this.duration = duration;
  this.velocity = velocity;
  this.mute = mute;
  this.probability = probability;
  this.velocity_deviation = velocityDeviation;
  this.release_velocity = releaseVelocity;
}
 
Note.prototype.toString = function() {
  return '{pitch:' + this.pitch +
         ', start_time:' + this.start_time +
         ', duration:' + this.duration +
         ', velocity:' + this.velocity +
         ', mute:' + this.mute +
         ', probability:' + this.probability +
         ', velocity_deviation:' + this.velocity_deviation +
         ', release_velocity:' + this.release_velocity + '}';
}

Note.MIN_DURATION = 1/128;
 
Note.prototype.getPitch = function() {
  if(this.pitch < 0) return 0;
  if(this.pitch > 127) return 127;
  return this.pitch;
}
 
Note.prototype.getStartTime = function() {
  // we convert to strings with decimals to work around a bug in Max
  // otherwise we get an invalid syntax error when trying to set notes
  if(this.start_time <= 0) return "0.0";
  return this.start_time.toFixed(4);
}
 
Note.prototype.getDuration = function() {
  if(this.duration <= Note.MIN_DURATION) return Note.MIN_DURATION;
  return this.duration.toFixed(4); // workaround similar bug as with getStart()
}
 
Note.prototype.getVelocity = function() {
  if(this.velocity < 1) return 1;
  if(this.velocity > 127) return 127;
  return this.velocity;
}
 
Note.prototype.getMute = function() {
  if(this.mute) return 1;
  return 0;
}

Note.prototype.getProbability = function() {
  if(this.probability < 0.0) return 0.0;
  if(this.probability > 1.0) return 1.0;
  return this.probability;
}

Note.prototype.getVelocityDeviation = function() {
  if(this.velocity_deviation < -127.0) return -127.0;
  if(this.velocity_deviation > 127.0) return 127.0;
  return this.velocity_deviation;
}

Note.prototype.getReleaseVelocity = function() {
  if(this.release_velocity < 1) return 1;
  if(this.release_velocity > 127) return 127;
  return this.release_velocity;
}
 
//--------------------------------------------------------------------

function filterOctave (pitch) {
  var lo_MIDI = (lo_oct + 2) * 12;
  var hi_MIDI = ((hi_oct + 2) * 12) - 1;
  if (lo_oct >= hi_oct) {
	pitch = null;
	return pitch;
  }
  if (pitch < lo_MIDI) {
	pitch = lo_MIDI + (pitch % 12);
    return pitch;
  }
  if (pitch > hi_MIDI) {
	if ((pitch % 12) == 0) {
	  pitch = hi_MIDI;
	} else {
	pitch = (hi_MIDI - 12) + (pitch % 12);
	}
    return pitch;
  }
  return pitch;
}

function calculatePitchState (pitch) {
  // determine the note in the scale
  var pitch_class = pitch % 12;
	
  // check if the note has been filtered out
  var pitch_state = true;
	
  if (pitch_class == 0) {
    if (c_natural == false) {
	  pitch_state = false;
	}
  }
	
  if (pitch_class == 1) {
    if (c_sharp == false) {
	  pitch_state = false;
	}
  }
	
  if (pitch_class == 2) {
    if (d_natural == false) {
	  pitch_state = false;
    }
  }
	
  if (pitch_class == 3) {
    if (d_sharp == false) {
	  pitch_state = false;
	}
  }
	
  if (pitch_class == 4) {
    if (e_natural == false) {
	  pitch_state = false;
	}
  }
	
  if (pitch_class == 5) {
    if (f_natural == false) {
	  pitch_state = false;
	}
  }

  if (pitch_class == 6) {
    if (f_sharp == false) {
	  pitch_state = false;
	}
  }
	
  if (pitch_class == 7) {
    if (g_natural == false) {
	  pitch_state = false;
	}
  }
	
  if (pitch_class == 8) {
    if (g_sharp == false) {
	  pitch_state = false;
	}
  }
	
  if (pitch_class == 9) {
    if (a_natural == false) {
	  pitch_state = false;
    }
  }
	
  if (pitch_class == 10) {
	if (a_sharp == false) {
	  pitch_state = false;
	}
  }
	
  if (pitch_class == 11) {
	if (b_natural == false) {
	  pitch_state = false;
	}
  }
  return pitch_state;
}

function increment(pitch, search_direction) {
  if (search_direction == "up") {
	for (i = 0; i < 12; i++) {
      pitch += 1;
      if (calculatePitchState(pitch) == true) {return pitch};
	}
	pitch = null;
	return pitch;
  } else {
	for (i = 0; i < 12; i++) {
	  pitch -= 1;  
      if (calculatePitchState(pitch) == true) {return pitch};
    }
    pitch = null;
    return pitch;
  }
}

function setReplacementNotes (replacement_notes) {
  replacement_notes_global = replacement_notes;
}

function anything() {
  // parse the notes
  var themessage = arrayfromargs(messagename, arguments);
  var notes = JSON.parse(themessage).notes;
  var arrayLength = notes.length;

  // check if note buffer is empty
  if (buffer_state == 0) {
    var replacement_notes = [];
  }

  // parse each individual note
  for (var i = 0; i < arrayLength; i++) {
	var search_direction = "up";
	
	// set the search direction to up or down
	var dice_roll = Math.random();
	
	if (dice_roll >= 0.5) {
      search_direction = "up";
    } else {
	  search_direction = "down";
	}
	
	// check if the note has been filtered out
	var pitch = notes[i].pitch;
	pitch = increment(pitch, search_direction);
	if (pitch != null) {
	  pitch = filterOctave(pitch);
	}
	
    // calculate other note attributes
    start_time = notes[i].quantizedStartStep / 4;
    duration = (notes[i].quantizedEndStep - notes[i].quantizedStartStep) / 4;
    velocity = velocity;
    mute = 0;
    probability = probability;
    velocity_deviation = velocity_deviation;
    release_velocity = release_velocity;     
    replacement_notes.push(new Note(pitch, start_time, duration, velocity, mute, probability, velocity_deviation, release_velocity));
  }
  // designate the note buffer as "filled"
  setReplacementNotes(replacement_notes);
  buffer_state = 1;
}

function launch() {
  if (buffer_state == 1) {
    var clip = new Clip();
    clip.replaceAllNotes(replacement_notes_global);
  }
}