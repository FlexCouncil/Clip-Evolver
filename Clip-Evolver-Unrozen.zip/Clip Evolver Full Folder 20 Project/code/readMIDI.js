// Adapted from http://compusition.com by Adam Murray.
// This devices also uses Magenta.js, which operates under the following license:
// https://github.com/magenta/magenta-js/blob/master/LICENSE

inlets = 1;
outlets = 1;

var track = 0;
var scene = 0;

function setTrack(inputTrack) {
  track = inputTrack;
}

function setScene(inputScene) {
  scene = inputScene;
}

//--------------------------------------------------------------------
// Clip class
 
function Clip() {
  var path = "live_set tracks " + track + " clip_slots " + scene + " clip";
  this.liveObject = new LiveAPI(path);
}
  
Clip.prototype.getLength = function() {
  return this.liveObject.get('length');
}
  
Clip.prototype.getNotes = function(startTime, timeRange, startPitch, pitchRange) {
  if(!startTime) startTime = 0;
  if(!timeRange) timeRange = this.getLength();
  if(!startPitch) startPitch = 0;
  if(!pitchRange) pitchRange = 128;
  
  var data = this.liveObject.call("get_notes_extended", startTime, startPitch, timeRange, pitchRange);

  var notes = [];
  // data starts with "notes"/count and ends with "done" (which we ignore)
  for(var i=2,len=data.length-1; i<len; i+=6) {
    // each note starts with "note" (which we ignore) and is 6 items in the list
    var note = new Note(data[i+1], data[i+2], data[i+3], data[i+4], data[i+5]);
    notes.push(note);
  }
  return notes;
}

//--------------------------------------------------------------------
// Note class
 
function Note(pitch, start, duration, velocity, muted) {
  this.pitch = pitch;
  this.start = start;
  this.duration = duration;
  this.velocity = velocity;
  this.muted = muted;
}
 
Note.prototype.toString = function() {
  return '{pitch:' + this.pitch +
         ', start:' + this.start +
         ', duration:' + this.duration +
         ', velocity:' + this.velocity +
         ', muted:' + this.muted + '}';
}
 
//--------------------------------------------------------------------

function launch() {
  var clip = new Clip();
  var notes = clip.getNotes();
  outlet(0, JSON.stringify(notes));
}