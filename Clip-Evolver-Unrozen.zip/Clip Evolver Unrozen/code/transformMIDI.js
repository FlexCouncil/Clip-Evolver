// This devices uses Magenta.js, which operates under the following license:
// https://github.com/magenta/magenta-js/blob/master/LICENSE

// declare variables

const maxApi = require("max-api");
const readline = require('readline');

const mrnn = require('@magenta/music/node/music_rnn');
var rnn = new mrnn.MusicRNN('https://storage.googleapis.com/magentadata/js/checkpoints/music_rnn/melody_rnn');

const mvae = require('@magenta/music/node/music_vae');

var vae = new mvae.MusicVAE('https://storage.googleapis.com/magentadata/js/checkpoints/music_vae/mel_4bar_small_q2');
// var vae = new mvae.MusicVAE('https://storage.googleapis.com/magentadata/js/checkpoints/music_vae/mel_4bar_med_q2');
// var vae = new mvae.MusicVAE('https://storage.googleapis.com/magentadata/js/checkpoints/music_vae/mel_4bar_med_lokl_q2');
// var vae = new mvae.MusicVAE('https://storage.googleapis.com/magentadata/js/checkpoints/music_vae/mel_2bar_small');
// var vae = new mvae.MusicVAE('https://storage.googleapis.com/magentadata/js/checkpoints/music_vae/mel_4bar_small_q2', spec?: MusicVAESpec);

const core = require('@magenta/music/node/core');

var fs = require('fs')

var temperature = 0.8;
var length = 64;
var returned_rnn_notes_global = [];
var returned_vae_notes_global = [];
var sequence_counter = 1;
var interpolate_number = 0;
var interpolate = false;
var notes_returned = false;

// initialize model

const initializeRNN = async () => {
  try {
    await rnn.initialize();
  } catch (error) {
    console.error(error);
  }
}

initializeRNN();

const initializeVAE = async () => {
  try {
    await vae.initialize();
  } catch (error) {
    console.error(error);
  }
}

initializeVAE();

function getPosition(string, subString, index) {
  return string.split(subString, index).join(subString).length;
}

function nthIndex(str, pat, n){
    var L= str.length, i= -1;
    while(n-- && i++<L){
        i= str.indexOf(pat, i);
        if (i < 0) break;
    }
    return i;
}

function setReturnedRNNNotes (returned_rnn_notes) {
  returned_rnn_notes_global = returned_rnn_notes;
}

function setReturnedVAENotes (returned_vae_notes) {
  returned_vae_notes_global = returned_vae_notes;
}

// process messages

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
  terminal: false
});

rl.on('line', async function(line){
 
  var run_alogrithm = true;

  if (line.startsWith("temp")) {
    temperature = parseFloat(line.slice(4));
    run_alogrithm = false;
  }

  if (line.startsWith("length")) {
    length = parseFloat(line.slice(6));
    run_alogrithm = false;
  }

  if (line.startsWith("interp")) {
    interpolate_number = parseFloat(line.slice(6));
      if (interpolate_number == 0) {
	    interpolate = false;
	    maxApi.post("INTERPOLATE OFF");
	    maxApi.post(interpolate);
	  } else {
        interpolate = true;
	    maxApi.post("INTERPOLATE ON");
	    maxApi.post(interpolate);
        sequence_counter = 1;
      }
    run_alogrithm = false;
  }

  line = line.replace(/\\/g, '');
  line = line.replace(' ', '');

  if (run_alogrithm) {

    // parse notes
    var count = (line.match(/}/g) || []).length;

    var notes = [];

    for (i = 0; i < count; i++) {
      var beg = nthIndex(line, '{', i + 1) + 2;
      var end = nthIndex(line, '}', i + 1);
      var note = line.slice(beg, end);
      var mute_colon = nthIndex(note, ':', 5) + 1;
      var mute = note.slice(mute_colon);
      var velocity_colon = nthIndex(note, ':', 4) + 1;
      var velocity = note.slice(velocity_colon);
      var velocity_crop = parseFloat(velocity.slice(0, velocity.indexOf(',')));
      var duration_colon = nthIndex(note, ':', 3) + 1;
      var duration = note.slice(duration_colon);
      var duration_crop = parseFloat(duration.slice(0, duration.indexOf(',')));
      var start_colon = nthIndex(note, ':', 2) + 1;
      var start = note.slice(start_colon);
      var start_crop = parseFloat(start.slice(0, start.indexOf(',')));
      var pitch_colon = nthIndex(note, ':', 1) + 1;
      var pitch = note.slice(pitch_colon);
      var pitch_crop = parseFloat(pitch.slice(0, pitch.indexOf(',')));
      var quantizedStartStep = Math.round(start_crop * 4);
      var quantizedEndStep = Math.round((start_crop + duration_crop) * 4);   
      var noteAttributes = {
        pitch: pitch_crop,
        quantizedStartStep: quantizedStartStep,
        quantizedEndStep: quantizedEndStep,
        velocity: velocity_crop
      };
      if (mute == 0) {
        notes[i] = noteAttributes;
      }
    };

    var noteSequence = {
	  notes: notes,
	  quantizationInfo: {stepsPerQuarter: 4},
	  tempos: [{time: 0, qpm: 120}],
	  totalQuantizedSteps: 64
    };

    // infer model

    if (interpolate) {
      if (sequence_counter == 1) {
        const runRNN = async () => {
          try {
	        notes_returned = false;
            const returned_rnn_notes = await rnn.continueSequence(noteSequence, length, temperature);
            setReturnedRNNNotes(returned_rnn_notes);
	        maxApi.post("RUNNING RNN--SEQUENCE COUNTER");
            maxApi.post(sequence_counter);
          } catch (error) {
            console.error(error);
          }
        }
        runRNN();

        const runVAE = async () => {
          try {
            const returned_vae_notes = await vae.interpolate([noteSequence, returned_rnn_notes_global], 5, temperature);
            setReturnedVAENotes(returned_vae_notes);
	        maxApi.post("FIRST--returned_vae_notes_global[sequence_counter]");
            maxApi.post(returned_vae_notes_global[sequence_counter]);
	        maxApi.post("FIRST--sequence_counter");
            maxApi.post(sequence_counter);
	        maxApi.post("FIRST--temperature");
            maxApi.post(temperature);
            await maxApi.outlet(JSON.stringify(returned_vae_notes_global[sequence_counter]));
            notes_returned = true;
            maxApi.post("NOTES_RETURNED:");
            maxApi.post(notes_returned);

            if (notes_returned) {	      
              sequence_counter += 1;
	          maxApi.post("COUNTER INCREMENTED TO:");
              maxApi.post(sequence_counter);
            }
          } catch (error) {
          console.error(error);
          }
        }
        runVAE();
 
       // sequence_counter += 1;
        /*
        maxApi.post("NOTES_RETURNED:");
        maxApi.post(notes_returned);

        if (notes_returned) {	      
          sequence_counter += 1;
	      maxApi.post("COUNTER INCREMENTED TO:");
          maxApi.post(sequence_counter);
        }
        */
	
      } else {
        const runVAELink = async () => {
          try {
	        maxApi.post("LINK--returned_vae_notes_global[sequence_counter]");
            maxApi.post(returned_vae_notes_global[sequence_counter]);
	        maxApi.post("LINK--sequence_counter");
            maxApi.post(sequence_counter);
	        maxApi.post("LINK--temperature");
            maxApi.post(temperature);
            await maxApi.outlet(JSON.stringify(returned_vae_notes_global[sequence_counter]));
            if (sequence_counter == 4) {
	          sequence_counter = 1;
	        } else {
              sequence_counter += 1;
            }
          } catch (error) {
          console.error(error);
          }
        }
        runVAELink();

        /*
        if (sequence_counter == 4) {
	      sequence_counter = 1;
	    } else {
          sequence_counter += 1;
        }
        */
	  }
	
	} else {
      const runRNN = async () => {
        try {
	      // maxApi.post("NO INTERPOLATE RUNNING");
          const returned_rnn_notes = await rnn.continueSequence(noteSequence, length, temperature);
          await maxApi.outlet(JSON.stringify(returned_rnn_notes));
        } catch (error) {
          console.error(error);
        }
      }
      runRNN();
    }
  }

  // If you run this without Max, this will go to stdout, which is usually
  // the JS console. In a node.script object, this output is redirected to Max
  // with the prefix stdout
  console.log(`Echoing ${line} to stdout`);
});


maxApi.addHandler('error', function() {

  // This is also routed to Max and gets the prefix stderr
  console.error("Error: Does not compute");
});